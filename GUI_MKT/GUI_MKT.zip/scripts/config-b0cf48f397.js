angular.module("app").constant("myConfig", {
  baseUrlAttr:"http://10.13.254.188:1212",
  baseUrlPromo:"http://10.13.254.188:1212",
  baseUrlPack:"http://10.13.254.188:1212",
  timeout: 12e4
});
